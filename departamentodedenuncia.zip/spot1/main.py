from google.oauth2 import service_account
from kivymd.app import MDApp
from kivy.lang import Builder
from kivy.core.window import Window
from kivymd.uix.screen import MDScreen
from kivymd.uix.screenmanager import MDScreenManager
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDFlatButton
import pyrebase
from google.cloud import firestore
import os

# Configuração do Firebase
firebaseConfig = {
    "apiKey": "AIzaSyBBd8RiCM5RvnOU19bcqaEtQXKMq-Y8i_E",
    "authDomain": "denuncia-c788f.firebaseapp.com",
    "databaseURL": "https://denuncia-c788f-default-rtdb.firebaseio.com",
    "projectId": "denuncia-c788f",
    "storageBucket": "denuncia-c788f.appspot.com",
    "messagingSenderId": "33327699946",
    "appId": "1:33327699946:web:b06b9297b44a6ce3324493",
    "measurementId": "G-MNY6MG5FSB"
}

firebase = pyrebase.initialize_app(firebaseConfig)
auth = firebase.auth()
credentials = service_account.Credentials.from_service_account_file('denuncia-c788f-firebase-adminsdk-30612-75e3460419.json')

# Inicialize Firestore
cred_path = "denuncia-c788f-firebase-adminsdk-30612-75e3460419.json"  # Caminho para o arquivo de chave de conta de serviço
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = cred_path
firestore_client = firestore.Client()

def enviarEspecificacoesDenuncia(titulo, descricao, outrasInformacoes):
        try:
            # Adiciona as especificações da campanha à coleção "Publicacao"
            doc_ref = firestore_client.collection("Publicacao").add({
                "titulo": titulo,
                "descricao": descricao,
                "outrasInformacoes": outrasInformacoes
            })
            print("Especificação da campanha enviada com ID: ", doc_ref[1].id)
        except Exception as e:
            print("Erro ao enviar especificações da campanha: ", e)

class LoginScreen(MDScreen):
    dialog = None

    def login_user(self):
        email = self.ids.login_email.text
        password = self.ids.login_password.text
        try:
            auth.sign_in_with_email_and_password(email, password)
            self.manager.current = 'tela_principal'
        except Exception as e:
            self.show_error_dialog("Email ou senha incorretos")

    def show_error_dialog(self, message):
        if not self.dialog:
            self.dialog = MDDialog(
                text=message,
                buttons=[
                    MDFlatButton(
                        text="OK",
                        theme_text_color="Custom",
                        text_color=self.theme_cls.primary_color,
                        on_release=lambda x: self.dialog.dismiss()
                    ),
                ],
            )
        self.dialog.text = message
        self.dialog.open()

class RegisterScreen(MDScreen):
    dialog = None
    def register_user(self):
        email = self.ids.email_field.text
        password = self.ids.password_field.text
        username = self.ids.username_field.text  # Obtendo o nome de usuário
 
        try:
            user = auth.create_user_with_email_and_password(email, password)
            
            # Salvar o nome de usuário, email e senha no Firestore
            user_id = user['localId']
            user_ref = firestore_client.collection("users").document(user_id)
            user_ref.set({
                "username": username,
                "email": email,
                "password": password
            })
            
            self.manager.current = 'tela_de_login'
        except Exception as e:
            self.show_error_dialog(f"Erro ao criar usuário: {e}")

    def show_error_dialog(self, message):
        if not self.dialog:
            self.dialog = MDDialog(
                text=message,
                buttons=[
                    MDFlatButton(
                        text="OK",
                        theme_text_color="Custom",
                        text_color=self.theme_cls.primary_color,
                        on_release=lambda x: self.dialog.dismiss()
                    ),
                ],
            )
        self.dialog.text = message
        self.dialog.open()

class TelaPrincipal(MDScreen):
    pass

class Denuncia(MDScreen):
    def validate_fields(self):
        if not self.ids.cidade.text or not self.ids.bairro.text or not self.ids.objeto.text or not self.ids.suspeito.text or not self.ids.locomocao.text:
            self.show_alert_dialog("Todos os campos são obrigatórios!")
        else:
            self.show_alert_dialog("Denúncia confirmada!")

    def show_alert_dialog(self, message):
        dialog = MDDialog(
            text=message,
            buttons=[
                MDFlatButton(
                    text="OK",
                    on_release=lambda x: dialog.dismiss()
                )
            ],
        )
        dialog.open()

class Perfil(MDScreen):
    dialog = None

    def update_username(self):
        new_username = self.ids.new_username.text
        user = auth.current_user
        user_id = user['localId']

        try:
            user_ref = firestore_client.collection("users").document(user_id)
            user_ref.update({"username": new_username})
            self.show_info_dialog("Nome de usuário atualizado com sucesso.")
        except Exception as e:
            self.show_error_dialog(f"Erro ao atualizar nome de usuário: {e}")
    def show_error_dialog(self, message):
        if not self.dialog:
            self.dialog = MDDialog(
                text=message,
                buttons=[
                    MDFlatButton(
                        text="OK",
                        theme_text_color="Custom",
                        text_color=self.theme_cls.primary_color,
                        on_release=lambda x: self.dialog.dismiss()
                    ),
                ],
            )
        self.dialog.text = message
        self.dialog.open()
    def show_info_dialog(self, message):
            if not self.dialog:
                self.dialog = MDDialog(
                    text=message,
                    buttons=[
                        MDFlatButton(
                            text="OK",
                            theme_text_color="Custom",
                            text_color=self.theme_cls.primary_color,
                            on_release=lambda x: self.dialog.dismiss()
                        ),
                    ],
                )
            self.dialog.text = message
            self.dialog.open()

class MyApp(MDApp):
    dialog = None

    def build(self):
        Window.size = (300, 600)
        Builder.load_file('main.kv')
        sm = MDScreenManager()
        sm.add_widget(LoginScreen(name="tela_de_login"))
        sm.add_widget(RegisterScreen(name="tela_de_cadastro"))
        sm.add_widget(TelaPrincipal(name="tela_principal"))
        sm.add_widget(Denuncia(name="tela_denuncia"))
        sm.add_widget(Perfil(name="tela_de_perfil"))
        return sm

    def show_alert_dialog(self):
        if not self.dialog:
            self.dialog = MDDialog(
                text="Sua denúncia foi feita com sucesso!",
                buttons=[
                    MDFlatButton(
                        text="Ok",
                        theme_text_color="Custom",
                        text_color='#0081F8',
                        on_release=lambda *args: self.denuncia_and_dismiss()
                    ),
                ],
            )
        self.dialog.open()
    
    def denuncia_and_dismiss(self):
        self.dialog.dismiss()
        self.root.current = 'tela_principal'

    def login(self):
        email = self.root.get_screen('login_screen').ids.login_email.text
        password = self.root.get_screen('login_screen').ids.login_password.text
        try:
            auth.sign_in_with_email_and_password(email, password)
            self.root.current = "tela_principal"
        except:
            self.show_error_dialog("Login Failed. Please check your credentials.")

    def register(self):
        email = self.root.get_screen('tela_de_cadastro').ids.register_email.text
        password = self.root.get_screen('tela_de_cadastro').ids.register_password.text
        try:
            auth.create_user_with_email_and_password(email, password)
            self.root.current = "login_screen"
        except:
            self.show_error_dialog("Registration Failed. Please try again.")

    def show_error_dialog(self, message):
        if not self.dialog:
            self.dialog = MDDialog(
                text=message,
                buttons=[
                    MDFlatButton(
                        text="Ok",
                        theme_text_color="Custom",
                        text_color='#FF0000',
                        on_release=lambda *args: self.dialog.dismiss()
                    ),
                ],
            )
        self.dialog.open()

if __name__ == "__main__":
    MyApp().run()